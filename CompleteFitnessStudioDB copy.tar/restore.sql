--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.5
-- Dumped by pg_dump version 15.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Sprint1FitnessGym";
--
-- Name: Sprint1FitnessGym; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Sprint1FitnessGym" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE "Sprint1FitnessGym" OWNER TO postgres;

\connect "Sprint1FitnessGym"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Address" (
    address_id integer NOT NULL,
    street_add character varying(30) NOT NULL,
    prov character varying(32) NOT NULL,
    postal_code character varying(7) NOT NULL,
    city character varying(24)
);


ALTER TABLE public."Address" OWNER TO postgres;

--
-- Name: Address_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Address_address_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Address_address_id_seq" OWNER TO postgres;

--
-- Name: Address_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Address_address_id_seq" OWNED BY public."Address".address_id;


--
-- Name: Attendance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Attendance" (
    class_id integer NOT NULL,
    member_id integer NOT NULL,
    attendance_date date NOT NULL
);


ALTER TABLE public."Attendance" OWNER TO postgres;

--
-- Name: Billing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Billing" (
    billing_id integer NOT NULL,
    membership_id integer NOT NULL,
    bill_date date NOT NULL,
    due_date date NOT NULL,
    status character varying(24) NOT NULL,
    amount integer NOT NULL,
    fee_id integer NOT NULL,
    receipt_id integer NOT NULL
);


ALTER TABLE public."Billing" OWNER TO postgres;

--
-- Name: Billing_billing_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Billing_billing_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Billing_billing_id_seq" OWNER TO postgres;

--
-- Name: Billing_billing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Billing_billing_id_seq" OWNED BY public."Billing".billing_id;


--
-- Name: Equipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Equipment" (
    equipment_id integer NOT NULL,
    equip_name character varying(32) NOT NULL,
    status character varying(24) NOT NULL
);


ALTER TABLE public."Equipment" OWNER TO postgres;

--
-- Name: Equipment_equipment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Equipment_equipment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Equipment_equipment_id_seq" OWNER TO postgres;

--
-- Name: Equipment_equipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Equipment_equipment_id_seq" OWNED BY public."Equipment".equipment_id;


--
-- Name: Fees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Fees" (
    fee_id integer NOT NULL,
    fee_name character varying(24) NOT NULL,
    description character varying(64) NOT NULL,
    price integer NOT NULL
);


ALTER TABLE public."Fees" OWNER TO postgres;

--
-- Name: Fees_fee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Fees_fee_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Fees_fee_id_seq" OWNER TO postgres;

--
-- Name: Fees_fee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Fees_fee_id_seq" OWNED BY public."Fees".fee_id;


--
-- Name: FitnessClass; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."FitnessClass" (
    class_id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    capacity integer,
    studio_id integer
);


ALTER TABLE public."FitnessClass" OWNER TO postgres;

--
-- Name: FitnessClass_class_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."FitnessClass_class_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."FitnessClass_class_id_seq" OWNER TO postgres;

--
-- Name: FitnessClass_class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."FitnessClass_class_id_seq" OWNED BY public."FitnessClass".class_id;


--
-- Name: Instructor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Instructor" (
    instructor_id integer NOT NULL,
    name character varying(100) NOT NULL,
    contact_info character varying(100),
    availability character varying(100),
    address_id integer,
    studio_id integer
);


ALTER TABLE public."Instructor" OWNER TO postgres;

--
-- Name: Instructor_instructor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Instructor_instructor_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Instructor_instructor_id_seq" OWNER TO postgres;

--
-- Name: Instructor_instructor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Instructor_instructor_id_seq" OWNED BY public."Instructor".instructor_id;


--
-- Name: Location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Location" (
    studio_id integer NOT NULL,
    facility_name character varying(255) NOT NULL,
    fitness_room character varying(3) NOT NULL
);


ALTER TABLE public."Location" OWNER TO postgres;

--
-- Name: Location_studio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Location_studio_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Location_studio_id_seq" OWNER TO postgres;

--
-- Name: Location_studio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Location_studio_id_seq" OWNED BY public."Location".studio_id;


--
-- Name: Maintenance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Maintenance" (
    maintenance_id integer NOT NULL,
    equipment_id integer NOT NULL,
    schedule_date date NOT NULL,
    completed_date date,
    description character varying(84) NOT NULL,
    instructor_id integer NOT NULL
);


ALTER TABLE public."Maintenance" OWNER TO postgres;

--
-- Name: Maintenance_maintenance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Maintenance_maintenance_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Maintenance_maintenance_id_seq" OWNER TO postgres;

--
-- Name: Maintenance_maintenance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Maintenance_maintenance_id_seq" OWNED BY public."Maintenance".maintenance_id;


--
-- Name: Member; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Member" (
    member_id integer NOT NULL,
    name character varying(100) NOT NULL,
    contact_details character varying(100),
    member_status character varying(20),
    address_id integer
);


ALTER TABLE public."Member" OWNER TO postgres;

--
-- Name: Member_member_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Member_member_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Member_member_id_seq" OWNER TO postgres;

--
-- Name: Member_member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Member_member_id_seq" OWNED BY public."Member".member_id;


--
-- Name: Membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Membership" (
    membership_id integer NOT NULL,
    member_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date,
    payment_method character varying(45) NOT NULL,
    fee_id integer NOT NULL,
    active boolean DEFAULT true NOT NULL
);


ALTER TABLE public."Membership" OWNER TO postgres;

--
-- Name: Membership_membership_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Membership_membership_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Membership_membership_id_seq" OWNER TO postgres;

--
-- Name: Membership_membership_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Membership_membership_id_seq" OWNED BY public."Membership".membership_id;


--
-- Name: Receipt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Receipt" (
    receipt_id integer NOT NULL,
    payment_date date NOT NULL,
    amount_paid integer NOT NULL
);


ALTER TABLE public."Receipt" OWNER TO postgres;

--
-- Name: Receipt_receipt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Receipt_receipt_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Receipt_receipt_id_seq" OWNER TO postgres;

--
-- Name: Receipt_receipt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Receipt_receipt_id_seq" OWNED BY public."Receipt".receipt_id;


--
-- Name: RewardsProgram; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RewardsProgram" (
    reward_id integer NOT NULL,
    member_id integer NOT NULL,
    reward_description text,
    reward_amount numeric(10,2),
    reward_date date
);


ALTER TABLE public."RewardsProgram" OWNER TO postgres;

--
-- Name: RewardsProgram_reward_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RewardsProgram_reward_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."RewardsProgram_reward_id_seq" OWNER TO postgres;

--
-- Name: RewardsProgram_reward_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RewardsProgram_reward_id_seq" OWNED BY public."RewardsProgram".reward_id;


--
-- Name: Schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Schedule" (
    class_id integer NOT NULL,
    instructor_id integer NOT NULL,
    duration interval NOT NULL
);


ALTER TABLE public."Schedule" OWNER TO postgres;

--
-- Name: Address address_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Address" ALTER COLUMN address_id SET DEFAULT nextval('public."Address_address_id_seq"'::regclass);


--
-- Name: Billing billing_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Billing" ALTER COLUMN billing_id SET DEFAULT nextval('public."Billing_billing_id_seq"'::regclass);


--
-- Name: Equipment equipment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Equipment" ALTER COLUMN equipment_id SET DEFAULT nextval('public."Equipment_equipment_id_seq"'::regclass);


--
-- Name: Fees fee_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Fees" ALTER COLUMN fee_id SET DEFAULT nextval('public."Fees_fee_id_seq"'::regclass);


--
-- Name: FitnessClass class_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FitnessClass" ALTER COLUMN class_id SET DEFAULT nextval('public."FitnessClass_class_id_seq"'::regclass);


--
-- Name: Instructor instructor_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Instructor" ALTER COLUMN instructor_id SET DEFAULT nextval('public."Instructor_instructor_id_seq"'::regclass);


--
-- Name: Location studio_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Location" ALTER COLUMN studio_id SET DEFAULT nextval('public."Location_studio_id_seq"'::regclass);


--
-- Name: Maintenance maintenance_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Maintenance" ALTER COLUMN maintenance_id SET DEFAULT nextval('public."Maintenance_maintenance_id_seq"'::regclass);


--
-- Name: Member member_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Member" ALTER COLUMN member_id SET DEFAULT nextval('public."Member_member_id_seq"'::regclass);


--
-- Name: Membership membership_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Membership" ALTER COLUMN membership_id SET DEFAULT nextval('public."Membership_membership_id_seq"'::regclass);


--
-- Name: Receipt receipt_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Receipt" ALTER COLUMN receipt_id SET DEFAULT nextval('public."Receipt_receipt_id_seq"'::regclass);


--
-- Name: RewardsProgram reward_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RewardsProgram" ALTER COLUMN reward_id SET DEFAULT nextval('public."RewardsProgram_reward_id_seq"'::regclass);


--
-- Data for Name: Address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Address" (address_id, street_add, prov, postal_code, city) FROM stdin;
\.
COPY public."Address" (address_id, street_add, prov, postal_code, city) FROM '$$PATH$$/3712.dat';

--
-- Data for Name: Attendance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Attendance" (class_id, member_id, attendance_date) FROM stdin;
\.
COPY public."Attendance" (class_id, member_id, attendance_date) FROM '$$PATH$$/3723.dat';

--
-- Data for Name: Billing; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Billing" (billing_id, membership_id, bill_date, due_date, status, amount, fee_id, receipt_id) FROM stdin;
\.
COPY public."Billing" (billing_id, membership_id, bill_date, due_date, status, amount, fee_id, receipt_id) FROM '$$PATH$$/3708.dat';

--
-- Data for Name: Equipment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Equipment" (equipment_id, equip_name, status) FROM stdin;
\.
COPY public."Equipment" (equipment_id, equip_name, status) FROM '$$PATH$$/3706.dat';

--
-- Data for Name: Fees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Fees" (fee_id, fee_name, description, price) FROM stdin;
\.
COPY public."Fees" (fee_id, fee_name, description, price) FROM '$$PATH$$/3714.dat';

--
-- Data for Name: FitnessClass; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."FitnessClass" (class_id, name, description, capacity, studio_id) FROM stdin;
\.
COPY public."FitnessClass" (class_id, name, description, capacity, studio_id) FROM '$$PATH$$/3716.dat';

--
-- Data for Name: Instructor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Instructor" (instructor_id, name, contact_info, availability, address_id, studio_id) FROM stdin;
\.
COPY public."Instructor" (instructor_id, name, contact_info, availability, address_id, studio_id) FROM '$$PATH$$/3718.dat';

--
-- Data for Name: Location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Location" (studio_id, facility_name, fitness_room) FROM stdin;
\.
COPY public."Location" (studio_id, facility_name, fitness_room) FROM '$$PATH$$/3725.dat';

--
-- Data for Name: Maintenance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Maintenance" (maintenance_id, equipment_id, schedule_date, completed_date, description, instructor_id) FROM stdin;
\.
COPY public."Maintenance" (maintenance_id, equipment_id, schedule_date, completed_date, description, instructor_id) FROM '$$PATH$$/3704.dat';

--
-- Data for Name: Member; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Member" (member_id, name, contact_details, member_status, address_id) FROM stdin;
\.
COPY public."Member" (member_id, name, contact_details, member_status, address_id) FROM '$$PATH$$/3720.dat';

--
-- Data for Name: Membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Membership" (membership_id, member_id, start_date, end_date, payment_method, fee_id, active) FROM stdin;
\.
COPY public."Membership" (membership_id, member_id, start_date, end_date, payment_method, fee_id, active) FROM '$$PATH$$/3727.dat';

--
-- Data for Name: Receipt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Receipt" (receipt_id, payment_date, amount_paid) FROM stdin;
\.
COPY public."Receipt" (receipt_id, payment_date, amount_paid) FROM '$$PATH$$/3710.dat';

--
-- Data for Name: RewardsProgram; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RewardsProgram" (reward_id, member_id, reward_description, reward_amount, reward_date) FROM stdin;
\.
COPY public."RewardsProgram" (reward_id, member_id, reward_description, reward_amount, reward_date) FROM '$$PATH$$/3722.dat';

--
-- Data for Name: Schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Schedule" (class_id, instructor_id, duration) FROM stdin;
\.
COPY public."Schedule" (class_id, instructor_id, duration) FROM '$$PATH$$/3728.dat';

--
-- Name: Address_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Address_address_id_seq"', 1, false);


--
-- Name: Billing_billing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Billing_billing_id_seq"', 1, false);


--
-- Name: Equipment_equipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Equipment_equipment_id_seq"', 1, false);


--
-- Name: Fees_fee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Fees_fee_id_seq"', 1, false);


--
-- Name: FitnessClass_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."FitnessClass_class_id_seq"', 1, false);


--
-- Name: Instructor_instructor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Instructor_instructor_id_seq"', 1, false);


--
-- Name: Location_studio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Location_studio_id_seq"', 1, false);


--
-- Name: Maintenance_maintenance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Maintenance_maintenance_id_seq"', 1, false);


--
-- Name: Member_member_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Member_member_id_seq"', 1, true);


--
-- Name: Membership_membership_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Membership_membership_id_seq"', 1, false);


--
-- Name: Receipt_receipt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Receipt_receipt_id_seq"', 1, false);


--
-- Name: RewardsProgram_reward_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RewardsProgram_reward_id_seq"', 1, false);


--
-- Name: Address Address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Address"
    ADD CONSTRAINT "Address_pkey" PRIMARY KEY (address_id);


--
-- Name: Billing Billing_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Billing"
    ADD CONSTRAINT "Billing_pkey" PRIMARY KEY (billing_id);


--
-- Name: Equipment Equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Equipment"
    ADD CONSTRAINT "Equipment_pkey" PRIMARY KEY (equipment_id);


--
-- Name: Fees Fees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Fees"
    ADD CONSTRAINT "Fees_pkey" PRIMARY KEY (fee_id);


--
-- Name: FitnessClass FitnessClass_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FitnessClass"
    ADD CONSTRAINT "FitnessClass_pkey" PRIMARY KEY (class_id);


--
-- Name: Instructor Instructor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Instructor"
    ADD CONSTRAINT "Instructor_pkey" PRIMARY KEY (instructor_id);


--
-- Name: Location Location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_pkey" PRIMARY KEY (studio_id);


--
-- Name: Maintenance Maintenance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Maintenance"
    ADD CONSTRAINT "Maintenance_pkey" PRIMARY KEY (maintenance_id);


--
-- Name: Member Member_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Member"
    ADD CONSTRAINT "Member_pkey" PRIMARY KEY (member_id);


--
-- Name: Membership Membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Membership"
    ADD CONSTRAINT "Membership_pkey" PRIMARY KEY (membership_id);


--
-- Name: Receipt Receipt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Receipt"
    ADD CONSTRAINT "Receipt_pkey" PRIMARY KEY (receipt_id);


--
-- Name: RewardsProgram RewardsProgram_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RewardsProgram"
    ADD CONSTRAINT "RewardsProgram_pkey" PRIMARY KEY (reward_id);


--
-- Name: Attendance Attendance_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Attendance"
    ADD CONSTRAINT "Attendance_class_id_fkey" FOREIGN KEY (class_id) REFERENCES public."FitnessClass"(class_id);


--
-- Name: Attendance Attendance_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Attendance"
    ADD CONSTRAINT "Attendance_member_id_fkey" FOREIGN KEY (member_id) REFERENCES public."Member"(member_id);


--
-- Name: Membership Membership_fee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Membership"
    ADD CONSTRAINT "Membership_fee_id_fkey" FOREIGN KEY (fee_id) REFERENCES public."Fees"(fee_id);


--
-- Name: Membership Membership_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Membership"
    ADD CONSTRAINT "Membership_member_id_fkey" FOREIGN KEY (member_id) REFERENCES public."Member"(member_id);


--
-- Name: Schedule Schedule_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Schedule"
    ADD CONSTRAINT "Schedule_class_id_fkey" FOREIGN KEY (class_id) REFERENCES public."FitnessClass"(class_id);


--
-- Name: Schedule Schedule_instructor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Schedule"
    ADD CONSTRAINT "Schedule_instructor_id_fkey" FOREIGN KEY (instructor_id) REFERENCES public."Instructor"(instructor_id);


--
-- Name: Membership fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Membership"
    ADD CONSTRAINT fk1 FOREIGN KEY (member_id) REFERENCES public."Member"(member_id);


--
-- Name: Attendance fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Attendance"
    ADD CONSTRAINT fk1 FOREIGN KEY (member_id) REFERENCES public."Member"(member_id);


--
-- Name: Schedule fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Schedule"
    ADD CONSTRAINT fk1 FOREIGN KEY (instructor_id) REFERENCES public."Instructor"(instructor_id);


--
-- Name: FitnessClass fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FitnessClass"
    ADD CONSTRAINT fk1 FOREIGN KEY (studio_id) REFERENCES public."Location"(studio_id);


--
-- Name: Instructor fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Instructor"
    ADD CONSTRAINT fk1 FOREIGN KEY (studio_id) REFERENCES public."Location"(studio_id);


--
-- Name: Member fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Member"
    ADD CONSTRAINT fk1 FOREIGN KEY (address_id) REFERENCES public."Address"(address_id);


--
-- Name: RewardsProgram fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RewardsProgram"
    ADD CONSTRAINT fk1 FOREIGN KEY (member_id) REFERENCES public."Member"(member_id);


--
-- Name: Maintenance fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Maintenance"
    ADD CONSTRAINT fk1 FOREIGN KEY (equipment_id) REFERENCES public."Equipment"(equipment_id);


--
-- Name: Billing fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Billing"
    ADD CONSTRAINT fk1 FOREIGN KEY (membership_id) REFERENCES public."Membership"(membership_id);


--
-- Name: Membership fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Membership"
    ADD CONSTRAINT fk2 FOREIGN KEY (fee_id) REFERENCES public."Fees"(fee_id);


--
-- Name: Attendance fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Attendance"
    ADD CONSTRAINT fk2 FOREIGN KEY (class_id) REFERENCES public."FitnessClass"(class_id);


--
-- Name: Schedule fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Schedule"
    ADD CONSTRAINT fk2 FOREIGN KEY (class_id) REFERENCES public."FitnessClass"(class_id);


--
-- Name: Instructor fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Instructor"
    ADD CONSTRAINT fk2 FOREIGN KEY (address_id) REFERENCES public."Address"(address_id);


--
-- Name: Maintenance fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Maintenance"
    ADD CONSTRAINT fk2 FOREIGN KEY (instructor_id) REFERENCES public."Instructor"(instructor_id);


--
-- Name: Billing fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Billing"
    ADD CONSTRAINT fk2 FOREIGN KEY (fee_id) REFERENCES public."Fees"(fee_id);


--
-- Name: Billing fk3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Billing"
    ADD CONSTRAINT fk3 FOREIGN KEY (receipt_id) REFERENCES public."Receipt"(receipt_id);


--
-- PostgreSQL database dump complete
--

